<?php
?>
<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
        <link href="design.css" media="all" rel="stylesheet" type="text/css"/>
        <title>Suivi inventaire</title>
</head>

<body>
	<center>
	<h1>Bienvenue!</h1>
	<a href="listeProduit.php"> Liste produits/catégories </a>
	<br/>
	<a href="ajoutProduit.php"> Ajout d'un produit </a>
	<br/>
	<a href="ajoutCategorie.php"> Ajout d'une catégorie </a>
	<br/>
	<a href="suppressionProduit.php"> Suppression d'un produit </a>
	<br/>
	<a href="connexion.html"> Déconnexion </a>
	</center>
</body>
</html>